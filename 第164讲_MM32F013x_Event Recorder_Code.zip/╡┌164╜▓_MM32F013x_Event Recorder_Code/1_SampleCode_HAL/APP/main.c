/******************************************************************************
 * @file    main.c
 * @author  King
 * @version V1.00
 * @date    20-May-2020
 * @brief   ......
 ******************************************************************************
 * @attention
 *
 * THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
 * CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
 * TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
 * HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
 * CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
 * <H2><CENTER>&COPY; COPYRIGHT 2020 MINDMOTION </CENTER></H2>
******************************************************************************/


/* Define to prevent recursive inclusion ------------------------------------*/
#define __MAIN_C__


/* Includes -----------------------------------------------------------------*/
#include "main.h"


/* Includes -----------------------------------------------------------------*/
#include "systick.h"
#include "uart.h"
#include <easyflash.h>
#include "EventRecorder.h"

/* Includes -----------------------------------------------------------------*/
#include "bsp_led.h"


/* Private typedef ----------------------------------------------------------*/
/* Private define -----------------------------------------------------------*/
/* Private macro ------------------------------------------------------------*/
/* Private variables --------------------------------------------------------*/
/* Private function prototypes ----------------------------------------------*/
/* Private functions --------------------------------------------------------*/


/* Exported variables -------------------------------------------------------*/
/* Exported function prototypes ---------------------------------------------*/


/******************************************************************************
 * @brief
 * @param
 * @retval
 * @attention
******************************************************************************/
int main(void)
{
    uint8_t s_ucBuf[10] = "MM32";
    uint32_t t0 = 0, t1 = 0, t2 = 0, t3 = 0, t4 = 0;
    unsigned int Reboot_Time = 0;
    /* Init SysTick timer 1ms for SysTick_DelayMs */
    SysTick_Init(1000);

    /* Config UART1 with parameter(115200, N, 8, 1) for printf */
    UARTx_Configure(DEBUG_UART, 115200, UART_WordLength_8b, UART_StopBits_1, UART_Parity_No);

    /* Init LEDs GPIO */
    BSP_LED_Init();

    EventRecorderInitialize(EventRecordAll, 1U);
    EventRecorderStart();

    printf("\r\nMM32F013xR8T6 %s %s\r\n", __DATE__, __TIME__);

    printf("Reboot_Time is %d\n", Reboot_Time);               // ��ӡreboot_time��ֵ
    /* USER CODE END 2 */


    while (1)
    {
        /* Toggle LED1~LED4 status */
        /* Delay 500ms */
        EventStartA(0);
        BSP_LED1_TOGGLE();
        SysTick_DelayMs(200);

        EventStopA(0);
        EventStartA(1);
        SysTick_DelayMs(200);
        BSP_LED2_TOGGLE();
        EventStopA(1);

        EventStartA(2);
        SysTick_DelayMs(200);
        BSP_LED3_TOGGLE();
        EventStopA(2);

        t0++;
        EventStartAv(3, t0, t0);
        BSP_LED4_TOGGLE();
        EventStopAv(3, t0, t0);
        t1 += 1;
        t2 += 2;
        EventRecord2(1 + EventLevelAPI, t1, t2);
        t3 += 3;
        t4 += 4;
        EventRecord4(2 + EventLevelOp, t1, t2, t3, t4);
        EventRecordData(3 + EventLevelOp, s_ucBuf, sizeof(s_ucBuf));
        SysTick_DelayMs(200);
    }
}


/******************* (C) COPYRIGHT 2020 ************************END OF FILE***/


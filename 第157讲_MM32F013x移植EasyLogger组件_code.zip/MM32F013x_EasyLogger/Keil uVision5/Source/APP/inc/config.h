/*******************************************************************************
 * @file    config.h
 * @author  King
 * @version V1.00
 * @date    16-Sep-2020
 * @brief   ......
 *******************************************************************************
 * @attention
 * 
 * THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
 * CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
 * TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
 * HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
 * CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
 * <H2><CENTER>&COPY; COPYRIGHT 2020 MINDMOTION </CENTER></H2>
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CONFIG_H__
#define __CONFIG_H__


/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>


/* Includes ------------------------------------------------------------------*/
#include "HAL_conf.h"
#include "HAL_device.h"


/* Includes ------------------------------------------------------------------*/
#include "KEY.h"
#include "LED.h"
#include "MCU.h"
#include "RTC.h"


/* Includes ------------------------------------------------------------------*/
#include "task.h"


/* Includes ------------------------------------------------------------------*/
#include "shell.h"
#include "shell_cfg.h"
#include "shell_ext.h"
#include "shell_port.h"


/* Includes ------------------------------------------------------------------*/
#include "easyflash.h"
#include "ef_cfg.h"
#include "ef_def.h"


/* Includes ------------------------------------------------------------------*/
#include "elog.h"
#include "elog_cfg.h"
#include "elog_flash.h"
#include "elog_flash_cfg.h"


#endif


/******************* (C) COPYRIGHT 2020 *************************END OF FILE***/


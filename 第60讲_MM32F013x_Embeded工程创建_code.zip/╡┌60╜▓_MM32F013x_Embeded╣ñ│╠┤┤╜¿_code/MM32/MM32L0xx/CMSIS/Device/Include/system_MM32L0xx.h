/**************************************************************************//**
* @file    system_MM32L0xx.h
*****************************************************************************/

#ifndef __SYSTEM_MM32L0XX_H
#define __SYSTEM_MM32L0XX_H

extern void SystemInit (void);

#endif /* __SYSTEM_MM32L0XX_H*/
/*-------------------------(C) COPYRIGHT 2017 MindMotion ----------------------*/

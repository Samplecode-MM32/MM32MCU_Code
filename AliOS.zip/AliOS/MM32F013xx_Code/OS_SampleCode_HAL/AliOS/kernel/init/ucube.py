src     = Split('''
        aos_init.c
''')
aos_component('kernel_init', src)

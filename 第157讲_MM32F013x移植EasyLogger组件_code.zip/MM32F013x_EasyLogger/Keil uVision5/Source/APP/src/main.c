/*******************************************************************************
 * @file    main.c
 * @author  King
 * @version V1.00
 * @date    16-Sep-2020
 * @brief   ......
 *******************************************************************************
 * @attention
 * 
 * THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
 * CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
 * TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
 * HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
 * CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
 * <H2><CENTER>&COPY; COPYRIGHT 2020 MINDMOTION </CENTER></H2>
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#define __MAIN_C__


/* Includes ------------------------------------------------------------------*/
#include "main.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* Exported variables --------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EasyFlash_ENV_Demo(void)
{
    uint32_t startup_times = 0;
    char *old_startup_times, new_startup_times[30] = {0};

    old_startup_times = ef_get_env("startup_times");

    startup_times = atol(old_startup_times);

    startup_times++;
    sprintf(new_startup_times, "%d", startup_times);

    printf("\r\nThe system now startup %d times\r\n\r\n", startup_times);

    ef_set_env("startup_times", new_startup_times);
    ef_save_env();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
static void elog_user_assert_hook(const char* ex, const char* func, size_t line)
{
#ifdef ELOG_ASYNC_OUTPUT_ENABLE
    /* disable async output */
    elog_async_enabled(false);
#endif

    /* disable logger output lock */
    elog_output_lock_enabled(false);

    /* disable flash plugin lock */
    elog_flash_lock_enabled(false);

    /* output logger assert information */
    elog_a("elog", "(%s) has assert failed at %s:%ld.\n", ex, func, line);

    /* write all buffered log to flash */
    elog_flash_flush();

    while(1);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EasyLogger_SHELL_elog(char *argv)
{
    if(!strcmp(argv, "on"))
    {
        printf("\r\nelog on \r\n"); elog_set_output_enabled(true);
    }
    else if(!strcmp(argv, "off"))
    {
        printf("\r\nelog off\r\n"); elog_set_output_enabled(false);
    }
    else
    {
        printf("\r\nelog error\r\n");
    }
}
SHELL_EXPORT_CMD(elog, EasyLogger_SHELL_elog, EasyLogger output enabled);


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EasyLogger_SHELL_elog_flash(char *argv)
{
    if(!strcmp(argv, "read"))
    {
        printf("\r\nelog_flash read \r\n"); elog_flash_output_all();
    }
    else if(!strcmp(argv, "clean"))
    {
        printf("\r\nelog_flash clean\r\n"); elog_flash_clean();
    }
    else if(!strcmp(argv, "flush"))
    {
        printf("\r\nelog_flash flush\r\n"); elog_flash_flush();
    }
    else
    {
        printf("\r\nelog_flash error\r\n");
    }
}
SHELL_EXPORT_CMD(elog_flash, EasyLogger_SHELL_elog_flash, EasyLogger read/clean/flush flash log);


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EasyLogger_SHELL_elog_test(void)
{
    log_a("Hello EasyLogger!"); /* ����Assert  */
    log_e("Hello EasyLogger!"); /* ����Error   */
    log_w("Hello EasyLogger!"); /* ����Warn    */
    log_i("Hello EasyLogger!"); /* ��ϢInfo    */
    log_d("Hello EasyLogger!"); /* ����Debug   */
    log_v("Hello EasyLogger!"); /* ��ϸVerbose */
}
SHELL_EXPORT_CMD(elog_test, EasyLogger_SHELL_elog_test, EasyLogger test);


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void InitSystem(void)
{
    MCU_Init();

    LED_Init();

    KEY_Init();

    RTC_Configure();

    printf("\r\n\r\nMM32F0133C7P %s %s\r\n\r\n", __DATE__, __TIME__);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
int main(void)
{
    InitSystem();

    if(easyflash_init() == EF_NO_ERR)
    {
        EasyFlash_ENV_Demo();

        if(elog_init() == EF_NO_ERR)
        {
            elog_set_fmt(ELOG_LVL_ASSERT,  ELOG_FMT_ALL & ~ELOG_FMT_P_INFO);
            elog_set_fmt(ELOG_LVL_ERROR,   ELOG_FMT_LVL |  (ELOG_FMT_TAG  | ELOG_FMT_TIME));
            elog_set_fmt(ELOG_LVL_WARN,    ELOG_FMT_LVL |  (ELOG_FMT_TAG  | ELOG_FMT_TIME));
            elog_set_fmt(ELOG_LVL_INFO,    ELOG_FMT_LVL |  (ELOG_FMT_TAG  | ELOG_FMT_TIME));
            elog_set_fmt(ELOG_LVL_DEBUG,   ELOG_FMT_ALL & ~(ELOG_FMT_FUNC | ELOG_FMT_P_INFO));
            elog_set_fmt(ELOG_LVL_VERBOSE, ELOG_FMT_ALL & ~(ELOG_FMT_FUNC | ELOG_FMT_P_INFO));

            /* set EasyLogger assert hook */
            elog_assert_set_hook(elog_user_assert_hook);

            /* initialize EasyLogger Flash plugin */
            elog_flash_init();

            /* start EasyLogger */
            elog_start();
        }
    }

    while(1)
    {
        TASK_Scheduling();
    }
}


/******************* (C) COPYRIGHT 2020 *************************END OF FILE***/


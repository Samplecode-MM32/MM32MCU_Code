/******************************************************************************
 * @file    main.c
 * @author  King
 * @version V1.00
 * @date    20-May-2020
 * @brief   ......
 ******************************************************************************
 * @attention
 *
 * THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
 * CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
 * TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
 * HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
 * CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
 * <H2><CENTER>&COPY; COPYRIGHT 2020 MINDMOTION </CENTER></H2>
******************************************************************************/


/* Define to prevent recursive inclusion ------------------------------------*/
#define __MAIN_C__


/* Includes -----------------------------------------------------------------*/
#include "main.h"


/* Includes -----------------------------------------------------------------*/
#include "systick.h"
#include "uart.h"
#include <easyflash.h>

/* Includes -----------------------------------------------------------------*/
#include "bsp_led.h"
#include "SEGGER_RTT.h"
#include "SEGGER_RTT_Conf.h"


/* Private typedef ----------------------------------------------------------*/
/* Private define -----------------------------------------------------------*/
/* Private macro ------------------------------------------------------------*/
/* Private variables --------------------------------------------------------*/
/* Private function prototypes ----------------------------------------------*/
/* Private functions --------------------------------------------------------*/


/* Exported variables -------------------------------------------------------*/
/* Exported function prototypes ---------------------------------------------*/
#define YEAR   2021
#define MONTH  3
#define DAY    31

int GetKey;
double fa = 0.1f;
double fb = 2.0f;
int Cnt = 0;
char abDataIn[20] = {0};
int c = 0;


/******************************************************************************
 * @brief
 * @param
 * @retval
 * @attention
******************************************************************************/
int main(void)
{
    unsigned int Reboot_Time = 0;
    /* Init SysTick timer 1ms for SysTick_DelayMs */
    SysTick_Init(1000);

    /* Config UART1 with parameter(115200, N, 8, 1) for printf */
    UARTx_Configure(DEBUG_UART, 115200, UART_WordLength_8b, UART_StopBits_1, UART_Parity_No);

    /* Init LEDs GPIO */
    BSP_LED_Init();

    SEGGER_RTT_ConfigUpBuffer(0, NULL, NULL, 0, SEGGER_RTT_MODE_NO_BLOCK_SKIP);

    printf("\r\nMM32F032R8T6 %s %s\r\n", __DATE__, __TIME__);

    /* USER CODE BEGIN 2 */

    if(easyflash_init() == EF_NO_ERR)                         // ��ʼ���ɹ�
    {
        ef_get_env_blob("reboot_time", &Reboot_Time, 8, NULL);  // ����reboot_time��ֵ
    }
    Reboot_Time++;                                            // reboot_time��ֵ��1

    ef_set_env_blob("reboot_time", &Reboot_Time, 8);          // ����reboot_time��ֵ
    printf("Reboot_Time is %d\n", Reboot_Time);               // ��ӡreboot_time��ֵ
    /* USER CODE END 2 */

    SEGGER_RTT_ConfigDownBuffer(1, "DataIn", &abDataIn[0], sizeof(abDataIn),
                                SEGGER_RTT_MODE_NO_BLOCK_SKIP);

    SEGGER_RTT_ConfigUpBuffer(1, "DataIn", &abDataIn[0], sizeof(abDataIn),
                              SEGGER_RTT_MODE_NO_BLOCK_SKIP);

    SEGGER_RTT_printf(0, RTT_CTRL_BG_CYAN"SEGGER RTT Sample. Uptime: %.10dms.\r\n", /*OS_Time*/ 890912);
    // Formatted output on channel 0: SEGGER RTT Sample. Uptime: 890912ms

    SEGGER_RTT_WriteString(0, "Hello World from your target.\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BLACK"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_RED"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_GREEN"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_YELLOW"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_BLUE"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_MAGENTA"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_CYAN"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_WHITE"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_BRIGHT_RED"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_BRIGHT_GREEN"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_BRIGHT_YELLOW"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_BRIGHT_BLUE"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_BRIGHT_MAGENTA"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_BRIGHT_CYAN"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_BRIGHT_WHITE"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_BLUE"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BLACK"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_RED"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_GREEN"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_YELLOW"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BLUE"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_MAGENTA"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_CYAN"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_WHITE"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BRIGHT_BLACK"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BRIGHT_RED"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BRIGHT_GREEN"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BRIGHT_YELLOW"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BRIGHT_BLUE"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BRIGHT_MAGENTA"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BRIGHT_CYAN"Counter overflow!\r\n\r\n");
    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BRIGHT_WHITE"Counter overflow!\r\n\r\n");


    do
    {
        c = SEGGER_RTT_WaitKey();
    }
    while(c != 'c');

    SEGGER_RTT_TerminalOut(1, RTT_CTRL_BG_BRIGHT_CYAN"ERROR: Buffer overflow.\r\n");

    while(1)
    {
        /* Toggle LED1~LED4 status */
        BSP_LED1_TOGGLE();
        BSP_LED2_TOGGLE();
        BSP_LED3_TOGGLE();
        BSP_LED4_TOGGLE();
        Cnt++;
        SEGGER_RTT_printf(0, "%sCounter: %s%d\n",
                          RTT_CTRL_BG_CYAN,
                          RTT_CTRL_TEXT_BRIGHT_GREEN,
                          Cnt);
        fa += 0.0001f;
        fb -= 0.0002f;
        rtt_printf("floating test:\tfa = %f, fb = %f\r\n", fa, fb);//�˺���������ӡ�������ݡ�
        /* Delay 500ms */
        SysTick_DelayMs(500);
    }
}


/******************* (C) COPYRIGHT 2020 ************************END OF FILE***/


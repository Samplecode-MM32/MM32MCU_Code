/*******************************************************************************
 * @file    KEY.c
 * @author  King
 * @version V1.00
 * @date    16-Sep-2020
 * @brief   ......
 *******************************************************************************
 * @attention
 * 
 * THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
 * CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
 * TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
 * HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
 * CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
 * <H2><CENTER>&COPY; COPYRIGHT 2020 MINDMOTION </CENTER></H2>
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#define __KEY_C__


/* Includes ------------------------------------------------------------------*/
#include "KEY.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* Exported variables --------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void KEY_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(KEY_RCC, ENABLE);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = KEY_PIN;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPD;
    GPIO_Init(KEY_GPIO, &GPIO_InitStructure);

    TASK_Append(TASK_ID_KEY, KEY_Scan, 10);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void KEY_Handler(void)
{
    uint32_t pressed_times = 0;
    char *old_pressed_times, new_pressed_times[30] = {0};

    old_pressed_times = ef_get_env("pressed_times");

    pressed_times = atol(old_pressed_times);

    pressed_times++;
    sprintf(new_pressed_times, "%d", pressed_times);

    printf("The Key Pressed %d times\r\n", pressed_times);

    ef_set_env("pressed_times", new_pressed_times);
    ef_save_env();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void KEY_Scan(void)
{
    static uint8_t KeyState = 0;
    static uint8_t KeyCount = 0;

    if(KeyState == 0)
    {
        if(GPIO_ReadInputDataBit(KEY_GPIO, KEY_PIN) == Bit_SET)
        {
            if(KeyCount++ >= 5)
            {
                KeyCount = 0;
                KeyState = 1;

                printf("Key Pressed.\r\n");

                KEY_Handler();
            }
        }
        else
        {
            KeyCount = 0;
        }
    }
    else
    {
        if(GPIO_ReadInputDataBit(KEY_GPIO, KEY_PIN) != Bit_SET)
        {
            if(KeyCount++ >= 5)
            {
                KeyCount = 0;
                KeyState = 0;

                printf("Key Release.\r\n\r\n");
            }
        }
        else
        {
            KeyCount = 0;
        }
    }
}


/******************* (C) COPYRIGHT 2020 *************************END OF FILE***/


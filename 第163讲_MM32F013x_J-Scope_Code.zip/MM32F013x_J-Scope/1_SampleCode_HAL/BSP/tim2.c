/******************************************************************************
 * @attention
 *
 * THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
 * CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
 * TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
 * HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
 * CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
 * <H2><CENTER>&COPY; COPYRIGHT 2020 MINDMOTION </CENTER></H2>
******************************************************************************/


/* Define to prevent recursive inclusion ------------------------------------*/
#define __TIM2_C__


/* Includes -----------------------------------------------------------------*/
#include "tim2.h"
#include "SEGGER_RTT.h"
#include "SEGGER_RTT_Conf.h"


/* Private typedef ----------------------------------------------------------*/
/* Private define -----------------------------------------------------------*/
/* Private macro ------------------------------------------------------------*/
/*  ���Ҳ����ݣ�12bit��1������128����, 0-4095֮��仯 */

int i = 0;
const uint16_t g_SineWave128[] =
{
    2047, 2147, 2248, 2347, 2446, 2544, 2641, 2737, 2830, 2922, 3012, 3099, 3184, 3266, 3346, 3422,
    3494, 3564, 3629, 3691, 3749, 3803, 3852, 3897, 3938, 3974, 4006, 4033, 4055, 4072, 4084, 4092,
    4094, 4092, 4084, 4072, 4055, 4033, 4006, 3974, 3938, 3897, 3852, 3803, 3749, 3691, 3629, 3564,
    3494, 3422, 3346, 3266, 3184, 3099, 3012, 2922, 2830, 2737, 2641, 2544, 2446, 2347, 2248, 2147,
    2047, 1947, 1846, 1747, 1648, 1550, 1453, 1357, 1264, 1172, 1082,  995,  910,  828, 748,   672,
    600,  530,  465,  403,  345,  291,  242,  197,  156,  120,   88,   61,   39,   22,  10,     2,
    0,    2,   10,   22,   39,   61,   88,  120,  156,  197,  242,  291,  345,  403, 465,   530,
    600,  672,  748,  828,  910,  995, 1082, 1172, 1264, 1357, 1453, 1550, 1648, 1747, 1846, 1947,
};


/* Private variables --------------------------------------------------------*/
volatile uint32_t TIM2_DelayTicks = 0;


/* Private function prototypes ----------------------------------------------*/
/* Private functions --------------------------------------------------------*/


/* Exported variables -------------------------------------------------------*/
/* Exported function prototypes ---------------------------------------------*/


/******************************************************************************
 * @brief
 * @param
 * @retval
 * @attention
******************************************************************************/
void TIM2_Configure(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef        NVIC_InitStructure;

    TIM_DeInit(TIM2);

    /* Enable TIM2 Clock */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    /* Config TIM2 Every 1ms Generate Interrupt */
    TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
    TIM_TimeBaseStructure.TIM_Prescaler             = (RCC_GetSysClockFreq() / 1000 - 1);
    TIM_TimeBaseStructure.TIM_CounterMode           = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period                = (1000 - 1);
    TIM_TimeBaseStructure.TIM_ClockDivision         = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_RepetitionCounter     = 0;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

    /* Clear TIM2 Update Flag */
    TIM_ClearFlag(TIM2, TIM_FLAG_Update);

    /* Enable TIM2 Update Interrupt */
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

    /* Enable TIM2 */
    TIM_Cmd(TIM2, ENABLE);

    /* Enable TIM2 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}


/******************************************************************************
 * @brief
 * @param
 * @retval
 * @attention
******************************************************************************/
void TIM2_IRQHandler(void)
{

    /* Clear TIM2 Update Interrupt Flag */
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    SEGGER_RTT_Write(1, &g_SineWave128[(i++) % 128], 2);
    printf("\r\nMM32F032R8T6 %s %s\r\n", __DATE__, __TIME__);
}


/******************* (C) COPYRIGHT 2020 ************************END OF FILE***/


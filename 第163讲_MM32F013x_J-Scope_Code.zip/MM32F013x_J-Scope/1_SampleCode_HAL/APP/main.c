/******************************************************************************
 * @file    main.c
 * @author  King
 * @version V1.00
 * @date    20-May-2020
 * @brief   ......
 ******************************************************************************
 * @attention
 *
 * THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
 * CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
 * TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
 * HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
 * CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
 * <H2><CENTER>&COPY; COPYRIGHT 2020 MINDMOTION </CENTER></H2>
******************************************************************************/


/* Define to prevent recursive inclusion ------------------------------------*/
#define __MAIN_C__


/* Includes -----------------------------------------------------------------*/
#include "main.h"


/* Includes -----------------------------------------------------------------*/
#include "systick.h"
#include "uart.h"
#include <easyflash.h>

/* Includes -----------------------------------------------------------------*/
#include "bsp_led.h"
#include "SEGGER_RTT.h"
#include "SEGGER_RTT_Conf.h"
#include "tim2.h"

/* Private typedef ----------------------------------------------------------*/
/* Private define -----------------------------------------------------------*/
/* Private macro ------------------------------------------------------------*/
/* Private variables --------------------------------------------------------*/
/* Private function prototypes ----------------------------------------------*/
/* Private functions --------------------------------------------------------*/


/* Exported variables -------------------------------------------------------*/
/* Exported function prototypes ---------------------------------------------*/
#define YEAR   2021
#define MONTH  3
#define DAY    31

int GetKey;
double fa = 0.1f;
double fb = 2.0f;
int Cnt = 0;
char abDataIn[20] = {0};
int c = 0;
uint8_t buf[2048];
	
/******************************************************************************
 * @brief
 * @param
 * @retval
 * @attention
******************************************************************************/
int main(void)
{
    SysTick_Init(1000);

    /* Config UART1 with parameter(115200, N, 8, 1) for printf */
    UARTx_Configure(DEBUG_UART, 115200, UART_WordLength_8b, UART_StopBits_1, UART_Parity_No);

    /* Init LEDs GPIO */
    BSP_LED_Init();

	SEGGER_RTT_ConfigUpBuffer(1, "JScope_u2", buf, 2048, SEGGER_RTT_MODE_NO_BLOCK_SKIP);

    printf("\r\nMM32F032R8T6 %s %s\r\n", __DATE__, __TIME__);

    SEGGER_RTT_printf(0, RTT_CTRL_BG_CYAN"SEGGER RTT Sample. Uptime: %.10dms.\r\n", /*OS_Time*/ 890912);

    SEGGER_RTT_printf(1, RTT_CTRL_BG_CYAN"SEGGER RTT Sample. Uptime: %.10dms.\r\n", /*OS_Time*/ 890912);

    SEGGER_RTT_TerminalOut(1, RTT_CTRL_TEXT_GREEN"Counter overflow!\r\n\r\n");

    TIM2_Configure();

    while(1)
    {
        /* Toggle LED1~LED4 status */
        BSP_LED1_TOGGLE();
        BSP_LED2_TOGGLE();
        BSP_LED3_TOGGLE();
        BSP_LED4_TOGGLE();
        Cnt+=5;

        /* Delay 500ms */
        SysTick_DelayMs(20);
    }
}


/******************* (C) COPYRIGHT 2020 ************************END OF FILE***/

